from Funcoes import *
import os
from colorama import init, Fore

init(autoreset=True)

def limpar_tela():
    os.system('cls' if os.name == "nt" else 'clear')

def pausar():
    input(f"{Fore.BLUE} Digite ENTER para continuar...")


def exibir_menu():
    limpar_tela()
    print(f"{Fore.GREEN}===== MENU =====")
    print(f"1. Adicionar produto")
    print(f"2. Atualizar produto")
    print(f"3. Visualizar estoque")
    print(f"{Fore.RED}4. Excluir Produto")

    print(f"0. Sair")    

def processar_opcao(opcao):
    if opcao == "2":
        conteudo_procurado = input ("Digite o conteúdo que procura: ")
        numero_linha, linha_encontrada = localizar_produto("produtos_new.txt", conteudo_procurado)
        
        if linha_encontrada is not None:
            limpar_tela()
            print(f'{Fore.GREEN} O produto "{conteudo_procurado}" foi encontrado!')
            print()
            print(f' ======= ESTOQUE ATUAL ======== ')
            print()
            print(linha_encontrada)
            
            separa_produto = linha_encontrada.split(" - ")
            for produto in separa_produto:
                if produto.startswith("Produto:"):
                    produto_cadastrado = produto.split(":")[1] 
                break
              
            print()
            print()
            condicao = input ('Deseja continuar [s/n]: ')
            if condicao == "s":
                limpar_tela()
                nome_produto = produto_cadastrado
                preco_digitado = float(input("Digite o valor do produto: "))
                qtd_estoque = int(input("Digite a quantidade disponível: "))   
                preco_produto = f"R$ {preco_digitado:.2f}"
                lista_produtos = {
                            "Produto": nome_produto, 
                            "Preco": preco_produto, 
                            "Quantidade": qtd_estoque
                             } 

                nova_linha = " - ".join([f"{chave}:{valor}" for chave, valor in lista_produtos.items()])
                
                substituir_linha_arquivo("produtos_new.txt", numero_linha, nova_linha)
                print()
                print (f"{Fore.GREEN}Atualização realizada com sucesso!")
                print()                
                pausar()


        else:
            limpar_tela()
            print(f'{Fore.LIGHTRED_EX}O conteúdo "{conteudo_procurado}" não foi encontrado.')
            print()
            pausar()


    elif opcao == "1":
        nome_produto = input("Digite o produto: ")
        preco_digitado = float(input("Digite o valor do produto: "))
        qtd_estoque = int(input("Digite a quantidade disponível: "))
        preco_produto = f"R$ {preco_digitado:.2f}"        
        lista_inicial = {
            "Produto": nome_produto, 
            "Preco": preco_produto, 
            "Quantidade": qtd_estoque
        } 

        lista_produtos = " - ".join([f"{chave}:{valor}" for chave, valor in lista_inicial.items()])
        
        adicionar_produto(lista_produtos)
        print(f"-> {Fore.GREEN} Produto cadastrado com sucesso!")
        pausar()

                    

    elif opcao == "3":
        limpar_tela()
        print (f"-> {Fore.YELLOW}------- ESTOQUE ---------")
        print()
        formatar_lista("produtos_new.txt")
        ler_arquivo("produtos_new.txt")
        print()
        pausar()



    elif opcao == "0":
        print()
        print(f"-> {Fore.GREEN} Até Logo!")
        exit(0)

    elif opcao == "4":
        limpar_tela()
        
        conteudo_procurado = input ("Digite o conteúdo que procura: ")
        numero_linha, linha_encontrada = localizar_produto("produtos_new.txt", conteudo_procurado)
        
        if linha_encontrada is not None:
            limpar_tela()
            print(f'{Fore.GREEN} O produto {conteudo_procurado} foi encontrado!')
            print()
            print(f' ======= ESTOQUE ATUAL ======== ')
            print()
            print(linha_encontrada)
            print()
            print(f"{Fore.RED} =========== ATENÇÃO =============")
            print()
            print(f"{Fore.RED}O dados serão excluídos definitivamente")
            print()
            condicao = input (f"{Fore.RED}Deseja continuar [s/n]: ")
            if condicao == "s":
                nova_linha = ("")
                substituir_linha_arquivo("produtos_new.txt", numero_linha, nova_linha)
                remover_linhas_em_branco("produtos_new.txt")
                limpar_tela()
                print ("Produto excluído com sucesso!")
                pausar()

        
        else:
            limpar_tela()
            print(f'{Fore.LIGHTRED_EX}O conteúdo "{conteudo_procurado}" não foi encontrado.')
            print()
            pausar()



    else:
        print (f"-> {Fore.RED} Opção inválida. Digite novamente...")
        pausar()  
        
def executar_sistema():
    exibir_menu()
    opcao = input("Digite a opção desejada: ")
    limpar_tela()
    processar_opcao(opcao)
    executar_sistema()

executar_sistema()

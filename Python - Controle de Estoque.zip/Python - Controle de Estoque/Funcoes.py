def adicionar_produto(lista_produtos):
    arquivo_produtos = open ('produtos_new.txt', 'a')
    arquivo_produtos.write(str (lista_produtos) + "\n")
    arquivo_produtos.close()
    


def ler_arquivo(arquivo):
    arquivo = open("produtos_new.txt", "r")
    conteudo = arquivo.read()
    print (conteudo)
    arquivo.close()
    	


def localizar_produto(nome_arquivo, conteudo_procurado):
    with open("produtos_new.txt", 'r') as arquivo:
        for numero_linha, linha in enumerate(arquivo, start=1):
            if conteudo_procurado in linha:
                return numero_linha, linha.strip()
    return None, None




def remover_linhas_em_branco(nome_arquivo):
    with open("produtos_new.txt", 'r') as arquivo:
        linhas = arquivo.readlines()

    linhas_nao_vazias = [linha.strip() for linha in linhas if linha.strip() != ""]

    with open(nome_arquivo, 'w') as arquivo:
        arquivo.writelines(linhas_nao_vazias)






def formatar_lista(nome_arquivo):
    with open("produtos_new.txt", 'r') as arquivo:
        conteudo = arquivo.read()

    produtos = conteudo.split("Produto:")

    produtos_formatados = [f"Produto:{produto.strip()}" for produto in produtos if produto.strip() != ""]

    with open(nome_arquivo, 'w') as arquivo:
        arquivo.write("\n".join(produtos_formatados))




def substituir_linha_arquivo(nome_arquivo, numero_linha, nova_linha):
    with open("produtos_new.txt", 'r') as arquivo:
        linhas = arquivo.readlines()

    if numero_linha > 0 and numero_linha <= len(linhas):
        linhas[numero_linha - 1] = nova_linha + '\n'

        with open(nome_arquivo, 'w') as arquivo:
            arquivo.writelines(linhas)

